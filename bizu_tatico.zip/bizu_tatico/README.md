# Bizú Tático

App de preparação tática para EsPCEx, ESA, CFO PMBA e Soldado PMBA, com "Direcionamento Forçado" e "Estudo Baseado no Erro".

## Como rodar

1. Tenha o [Flutter SDK](https://flutter.dev) instalado (canal stable).
2. Na raiz do projeto:
   ```bash
   flutter pub get
   flutter run
   ```
3. Na primeira execução, o app popula automaticamente o banco SQLite local com os 4 editais (função `seedDatabaseIfNeeded()` em `lib/data/seed_data.dart`) e libera a primeira missão de cada concurso.

## Estrutura do projeto

```
lib/
  main.dart                     -> entry point
  database/
    database_helper.dart        -> schema SQLite + regras de negócio
                                    (nota de corte, recálculo dinâmico, corte de Pareto)
  models/
    concurso.dart
    missao.dart
  data/
    seed_data.dart               -> tópicos dos 4 editais (matérias sequenciais)
  screens/
    home_screen.dart             -> seleção do concurso
    concurso_screen.dart         -> "Missão do Dia" + "Painel" (dashboard)
  widgets/
    dashboard_chart.dart         -> gráfico de rosca (fl_chart)
```

## Fluxo de uso

1. **Home** — escolha um dos 4 concursos.
2. **Missão do Dia** — o app mostra a matéria/tópico da vez (Ordem do Dia) e pede quantas questões da meta você acertou.
   - Acima da nota de corte → missão concluída, próxima é liberada.
   - Abaixo da nota de corte:
     - **Pré-edital**: a missão volta amanhã como "Revisão Obrigatória" e a data estimada de conclusão anda +1 dia.
     - **Pós-edital** (depois de tocar em "Publicar Edital" no Painel): a data da prova fica travada e o app corta 1 tópico de baixa prioridade ainda bloqueado, para preservar o tempo nos tópicos de alta prioridade.
3. **Painel** — gráfico de rosca (concluídas / restantes / cortadas), barra de progresso geral e as datas estimada/da prova.

## Observações importantes

- Este projeto foi escrito diretamente como código-fonte Flutter/Dart; **não foi compilado nem testado em um SDK Flutter real** neste ambiente (aqui não há Flutter/Android/iOS toolchain disponível). Rode `flutter pub get` e `flutter analyze` antes do primeiro `flutter run` para pegar qualquer erro de sintaxe ou de versão de dependência.
- As listas de tópicos das matérias que o edital descreveu apenas como "estrutura padrão"/"estrutura expandida" (ex.: Direito Administrativo do CFO, todas as matérias do EsPCEx e da ESA) foram elaboradas com base em conteúdo programático típico desses concursos — vale revisar linha a linha contra o edital oficial mais recente antes de usar em estudo real.
- A prioridade (ALTA/MEDIA/BAIXA) de cada tópico — usada no Corte de Pareto — foi distribuída automaticamente por posição (40%/40%/20%). Ajuste manualmente em `seed_data.dart` os tópicos que, pela sua experiência de banca, merecem prioridade diferente.
- O Corte de Pareto, na versão atual, corta **um** tópico de baixa prioridade por falha (não todos de uma vez) — decisão de design pensada para não ser agressiva demais. Se quiser outro comportamento, é só ajustar `_aplicarCorteDeParetoNoConcurso()` em `database_helper.dart`.
