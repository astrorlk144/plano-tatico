import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

void main() {
  runApp(const BizuTaticoApp());
}

class BizuTaticoApp extends StatelessWidget {
  const BizuTaticoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Bizú Tático',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.blueGrey.shade800,
          primary: Colors.blueGrey.shade800,
        ),
        appBarTheme: AppBarTheme(
          backgroundColor: Colors.blueGrey.shade900,
          foregroundColor: Colors.white,
        ),
      ),
      home: const HomeScreen(),
    );
  }
}
