import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';

/// Gráfico de rosca: Missões Concluídas vs. Restantes vs. Cortadas (Pareto).
class DashboardChart extends StatelessWidget {
  final int concluidas;
  final int restantes;
  final int cortadas;

  const DashboardChart({
    super.key,
    required this.concluidas,
    required this.restantes,
    required this.cortadas,
  });

  @override
  Widget build(BuildContext context) {
    final total = concluidas + restantes + cortadas;
    if (total == 0) {
      return const SizedBox(
        height: 180,
        child: Center(child: Text('Sem missões cadastradas ainda.')),
      );
    }

    final sections = <PieChartSectionData>[
      PieChartSectionData(
        value: concluidas.toDouble(),
        color: Colors.green.shade600,
        title: '$concluidas',
        radius: 60,
        titleStyle: const TextStyle(
            fontSize: 14, fontWeight: FontWeight.bold, color: Colors.white),
      ),
      PieChartSectionData(
        value: restantes.toDouble(),
        color: Colors.blueGrey.shade400,
        title: '$restantes',
        radius: 60,
        titleStyle: const TextStyle(
            fontSize: 14, fontWeight: FontWeight.bold, color: Colors.white),
      ),
      if (cortadas > 0)
        PieChartSectionData(
          value: cortadas.toDouble(),
          color: Colors.orange.shade700,
          title: '$cortadas',
          radius: 60,
          titleStyle: const TextStyle(
              fontSize: 14, fontWeight: FontWeight.bold, color: Colors.white),
        ),
    ];

    return Column(
      children: [
        SizedBox(
          height: 180,
          child: PieChart(
            PieChartData(
              sections: sections,
              sectionsSpace: 2,
              centerSpaceRadius: 40,
            ),
          ),
        ),
        const SizedBox(height: 12),
        Wrap(
          spacing: 16,
          children: [
            _legendaItem(Colors.green.shade600, 'Concluídas'),
            _legendaItem(Colors.blueGrey.shade400, 'Restantes'),
            if (cortadas > 0) _legendaItem(Colors.orange.shade700, 'Cortadas (Pareto)'),
          ],
        ),
      ],
    );
  }

  Widget _legendaItem(Color cor, String texto) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(width: 12, height: 12, color: cor),
        const SizedBox(width: 6),
        Text(texto, style: const TextStyle(fontSize: 12)),
      ],
    );
  }
}
