import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

/// =====================================================================
/// BIZÚ TÁTICO — CAMADA DE BANCO DE DADOS (SQLite / sqflite)
/// =====================================================================
/// Este arquivo contém:
///   1. Criação do schema (5 tabelas)
///   2. CRUD básico
///   3. As regras de negócio centrais:
///      - Comando Diário (trava de segurança)
///      - Nota de Corte Dinâmica
///      - Algoritmo de Recálculo Dinâmico (fase pré-edital)
///      - Algoritmo de Corte de Pareto (fase pós-edital)
/// =====================================================================

class DatabaseHelper {
  DatabaseHelper._internal();
  static final DatabaseHelper instance = DatabaseHelper._internal();

  static Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB();
    return _database!;
  }

  Future<Database> _initDB() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'bizu_tatico.db');
    return await openDatabase(
      path,
      version: 1,
      onCreate: _createDB,
      onConfigure: (db) async => await db.execute('PRAGMA foreign_keys = ON'),
    );
  }

  // ===================================================================
  // SCHEMA
  // ===================================================================
  Future<void> _createDB(Database db, int version) async {
    // ------------------------------------------------------------------
    // CONCURSOS: EsPCEx, ESA, CFO PMBA, Soldado PMBA
    // ------------------------------------------------------------------
    await db.execute('''
      CREATE TABLE concursos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT NOT NULL UNIQUE,              -- 'ESPCEX', 'ESA', 'CFO_PMBA', 'SOLDADO_PMBA'
        nota_corte REAL NOT NULL,               -- 0.80 ou 0.75
        meta_questoes INTEGER NOT NULL,         -- 20, 25 ou 30
        data_inicio TEXT NOT NULL,
        data_estimada_conclusao TEXT NOT NULL,  -- recalculada dinamicamente (+1 dia por falha)
        data_prova TEXT,                        -- NULL até o edital ser publicado
        edital_publicado INTEGER NOT NULL DEFAULT 0  -- 0 = fase pré-edital, 1 = fase pós-edital
      )
    ''');

    // ------------------------------------------------------------------
    // MATÉRIAS: vinculadas a um concurso, com ordem sequencial
    // ------------------------------------------------------------------
    await db.execute('''
      CREATE TABLE materias (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        concurso_id INTEGER NOT NULL,
        nome TEXT NOT NULL,
        ordem INTEGER NOT NULL,
        FOREIGN KEY (concurso_id) REFERENCES concursos (id) ON DELETE CASCADE
      )
    ''');

    // ------------------------------------------------------------------
    // MISSÕES: os tópicos do edital (a menor unidade de estudo)
    // ------------------------------------------------------------------
    await db.execute('''
      CREATE TABLE missoes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        materia_id INTEGER NOT NULL,
        nome TEXT NOT NULL,
        ordem INTEGER NOT NULL,
        prioridade TEXT NOT NULL DEFAULT 'MEDIA',  -- 'ALTA', 'MEDIA', 'BAIXA' (recorrência na banca)
        status TEXT NOT NULL DEFAULT 'BLOQUEADA',  -- BLOQUEADA | LIBERADA | CONCLUIDA | REVISAO_OBRIGATORIA | CORTADA
        FOREIGN KEY (materia_id) REFERENCES materias (id) ON DELETE CASCADE
      )
    ''');

    // ------------------------------------------------------------------
    // TENTATIVAS: histórico de cada rodada de questões feita numa missão
    // ------------------------------------------------------------------
    await db.execute('''
      CREATE TABLE tentativas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        missao_id INTEGER NOT NULL,
        data TEXT NOT NULL,
        questoes_total INTEGER NOT NULL,
        acertos INTEGER NOT NULL,
        taxa_acerto REAL NOT NULL,
        aprovado INTEGER NOT NULL,  -- 0 ou 1, resultado frente à nota de corte do concurso
        FOREIGN KEY (missao_id) REFERENCES missoes (id) ON DELETE CASCADE
      )
    ''');

    // ------------------------------------------------------------------
    // LOG DE RECÁLCULO: cada vez que a data estimada foi empurrada,
    // ou que um tópico de baixa prioridade foi cortado (Pareto)
    // ------------------------------------------------------------------
    await db.execute('''
      CREATE TABLE log_recalculo (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        concurso_id INTEGER NOT NULL,
        data_evento TEXT NOT NULL,
        tipo TEXT NOT NULL,       -- 'ADIAMENTO' | 'CORTE_PARETO'
        descricao TEXT NOT NULL,
        FOREIGN KEY (concurso_id) REFERENCES concursos (id) ON DELETE CASCADE
      )
    ''');

    // Índices para acelerar as queries mais usadas (ordem do dia, dashboard)
    await db.execute('CREATE INDEX idx_materias_concurso ON materias (concurso_id, ordem)');
    await db.execute('CREATE INDEX idx_missoes_materia ON missoes (materia_id, ordem)');
    await db.execute('CREATE INDEX idx_missoes_status ON missoes (status)');
    await db.execute('CREATE INDEX idx_tentativas_missao ON tentativas (missao_id)');
  }

  // ===================================================================
  // COMANDO DIÁRIO — retorna a "Ordem do Dia"
  // ===================================================================
  /// Busca a próxima missão ativa do concurso: a primeira, em ordem,
  /// que esteja LIBERADA ou em REVISAO_OBRIGATORIA. É essa e só essa
  /// que o app deve mostrar ao aluno (trava de segurança).
  Future<Map<String, dynamic>?> getMissaoDoDia(int concursoId) async {
    final db = await database;
    final result = await db.rawQuery('''
      SELECT m.*, mat.nome AS materia_nome, mat.ordem AS materia_ordem
      FROM missoes m
      INNER JOIN materias mat ON mat.id = m.materia_id
      WHERE mat.concurso_id = ?
        AND m.status IN ('LIBERADA', 'REVISAO_OBRIGATORIA')
      ORDER BY mat.ordem ASC, m.ordem ASC
      LIMIT 1
    ''', [concursoId]);

    return result.isNotEmpty ? result.first : null;
  }

  // ===================================================================
  // REGISTRAR TENTATIVA — aplica nota de corte + dispara os algoritmos
  // ===================================================================
  /// Registra o resultado das questões do dia e decide o que acontece:
  ///   - Se bateu a nota de corte: conclui a missão e libera a próxima.
  ///   - Se não bateu:
  ///       * fase pré-edital -> Algoritmo de Recálculo Dinâmico
  ///       * fase pós-edital -> Algoritmo de Corte de Pareto
  Future<bool> registrarTentativa({
    required int missaoId,
    required int questoesTotal,
    required int acertos,
  }) async {
    final db = await database;

    final missao = (await db.query('missoes', where: 'id = ?', whereArgs: [missaoId])).first;
    final materiaId = missao['materia_id'] as int;
    final materia = (await db.query('materias', where: 'id = ?', whereArgs: [materiaId])).first;
    final concursoId = materia['concurso_id'] as int;
    final concurso = (await db.query('concursos', where: 'id = ?', whereArgs: [concursoId])).first;

    final notaCorte = concurso['nota_corte'] as double;
    final taxaAcerto = acertos / questoesTotal;
    final aprovado = taxaAcerto >= notaCorte;

    await db.insert('tentativas', {
      'missao_id': missaoId,
      'data': DateTime.now().toIso8601String(),
      'questoes_total': questoesTotal,
      'acertos': acertos,
      'taxa_acerto': taxaAcerto,
      'aprovado': aprovado ? 1 : 0,
    });

    if (aprovado) {
      await _concluirMissaoELiberarProxima(missaoId, materiaId, concursoId);
    } else {
      final editalPublicado = (concurso['edital_publicado'] as int) == 1;
      if (editalPublicado) {
        await _aplicarCorteDeParetoNoConcurso(concursoId);
        // A data da prova é imutável na fase pós-edital: a missão do dia
        // continua a mesma, apenas os tópicos de baixa prioridade lá na
        // frente são cortados para abrir espaço no cronograma.
        await db.update('missoes', {'status': 'REVISAO_OBRIGATORIA'},
            where: 'id = ?', whereArgs: [missaoId]);
      } else {
        await _recalcularDataDinamica(concursoId, missaoId);
      }
    }

    return aprovado;
  }

  Future<void> _concluirMissaoELiberarProxima(
      int missaoId, int materiaId, int concursoId) async {
    final db = await database;
    await db.update('missoes', {'status': 'CONCLUIDA'}, where: 'id = ?', whereArgs: [missaoId]);

    // Próxima missão na mesma matéria
    final missaoAtual = (await db.query('missoes', where: 'id = ?', whereArgs: [missaoId])).first;
    final proxima = await db.query(
      'missoes',
      where: 'materia_id = ? AND ordem > ? AND status = ?',
      whereArgs: [materiaId, missaoAtual['ordem'], 'BLOQUEADA'],
      orderBy: 'ordem ASC',
      limit: 1,
    );

    if (proxima.isNotEmpty) {
      await db.update('missoes', {'status': 'LIBERADA'},
          where: 'id = ?', whereArgs: [proxima.first['id']]);
      return;
    }

    // Matéria esgotada -> libera a primeira missão da próxima matéria do concurso
    final materiaAtual = (await db.query('materias', where: 'id = ?', whereArgs: [materiaId])).first;
    final proximaMateria = await db.query(
      'materias',
      where: 'concurso_id = ? AND ordem > ?',
      whereArgs: [concursoId, materiaAtual['ordem']],
      orderBy: 'ordem ASC',
      limit: 1,
    );

    if (proximaMateria.isNotEmpty) {
      final primeiraMissao = await db.query(
        'missoes',
        where: 'materia_id = ? AND status = ?',
        whereArgs: [proximaMateria.first['id'], 'BLOQUEADA'],
        orderBy: 'ordem ASC',
        limit: 1,
      );
      if (primeiraMissao.isNotEmpty) {
        await db.update('missoes', {'status': 'LIBERADA'},
            where: 'id = ?', whereArgs: [primeiraMissao.first['id']]);
      }
    }
    // Se não houver próxima matéria nem próxima missão: edital concluído 🎯
  }

  // ===================================================================
  // ALGORITMO DE RECÁLCULO DINÂMICO (fase pré-edital)
  // ===================================================================
  /// Falhou ou não estudou antes do edital sair: a missão vira revisão
  /// obrigatória pro dia seguinte e a data estimada de conclusão anda +1 dia.
  Future<void> _recalcularDataDinamica(int concursoId, int missaoId) async {
    final db = await database;

    await db.update('missoes', {'status': 'REVISAO_OBRIGATORIA'},
        where: 'id = ?', whereArgs: [missaoId]);

    final concurso = (await db.query('concursos', where: 'id = ?', whereArgs: [concursoId])).first;
    final dataAtual = DateTime.parse(concurso['data_estimada_conclusao'] as String);
    final novaData = dataAtual.add(const Duration(days: 1));

    await db.update(
      'concursos',
      {'data_estimada_conclusao': novaData.toIso8601String()},
      where: 'id = ?',
      whereArgs: [concursoId],
    );

    await db.insert('log_recalculo', {
      'concurso_id': concursoId,
      'data_evento': DateTime.now().toIso8601String(),
      'tipo': 'ADIAMENTO',
      'descricao': 'Meta não atingida — data estimada empurrada em +1 dia.',
    });
  }

  // ===================================================================
  // ALGORITMO DE CORTE DE PARETO (fase pós-edital)
  // ===================================================================
  /// A data da prova é fixa. Se o aluno falha, cortamos (ocultamos)
  /// tópicos futuros de prioridade BAIXA que ainda estejam BLOQUEADOS,
  /// para concentrar o tempo restante nos de prioridade ALTA.
  Future<void> _aplicarCorteDeParetoNoConcurso(int concursoId) async {
    final db = await database;

    final candidatos = await db.rawQuery('''
      SELECT m.id, m.nome
      FROM missoes m
      INNER JOIN materias mat ON mat.id = m.materia_id
      WHERE mat.concurso_id = ?
        AND m.prioridade = 'BAIXA'
        AND m.status = 'BLOQUEADA'
      ORDER BY mat.ordem ASC, m.ordem ASC
      LIMIT 1
    ''', [concursoId]);

    if (candidatos.isEmpty) return; // nada de baixa prioridade sobrando pra cortar

    final missaoCortada = candidatos.first;
    await db.update('missoes', {'status': 'CORTADA'},
        where: 'id = ?', whereArgs: [missaoCortada['id']]);

    await db.insert('log_recalculo', {
      'concurso_id': concursoId,
      'data_evento': DateTime.now().toIso8601String(),
      'tipo': 'CORTE_PARETO',
      'descricao': 'Tópico "${missaoCortada['nome']}" cortado (baixa prioridade) para preservar a data da prova.',
    });
  }

  // ===================================================================
  // PUBLICAR EDITAL — trava a data da prova e muda a fase do concurso
  // ===================================================================
  Future<void> publicarEdital(int concursoId, DateTime dataProva) async {
    final db = await database;
    await db.update(
      'concursos',
      {
        'edital_publicado': 1,
        'data_prova': dataProva.toIso8601String(),
      },
      where: 'id = ?',
      whereArgs: [concursoId],
    );
  }

  // ===================================================================
  // DASHBOARD — dados para o gráfico de rosca e a barra de progresso
  // ===================================================================
  Future<Map<String, dynamic>> getDashboardData(int concursoId) async {
    final db = await database;

    final counts = await db.rawQuery('''
      SELECT m.status, COUNT(*) as total
      FROM missoes m
      INNER JOIN materias mat ON mat.id = m.materia_id
      WHERE mat.concurso_id = ?
      GROUP BY m.status
    ''', [concursoId]);

    final Map<String, int> statusMap = {
      'BLOQUEADA': 0,
      'LIBERADA': 0,
      'CONCLUIDA': 0,
      'REVISAO_OBRIGATORIA': 0,
      'CORTADA': 0,
    };
    for (final row in counts) {
      statusMap[row['status'] as String] = row['total'] as int;
    }

    final totalMissoes = statusMap.values.fold<int>(0, (a, b) => a + b);
    final concluidas = statusMap['CONCLUIDA']!;
    // "Restantes" para fins do gráfico exclui as que foram cortadas do escopo
    final restantes = totalMissoes - concluidas - statusMap['CORTADA']!;
    final progresso = totalMissoes == 0 ? 0.0 : concluidas / (totalMissoes - statusMap['CORTADA']!);

    final concurso = (await db.query('concursos', where: 'id = ?', whereArgs: [concursoId])).first;

    return {
      'concluidas': concluidas,
      'restantes': restantes,
      'cortadas': statusMap['CORTADA'],
      'progresso_percentual': progresso, // 0.0 a 1.0 -> multiplicar por 100 na UI
      'data_estimada_conclusao': concurso['data_estimada_conclusao'],
      'data_prova': concurso['data_prova'],
      'edital_publicado': concurso['edital_publicado'] == 1,
    };
  }

  // ===================================================================
  // SEED HELPERS — usados na etapa de inserção de dados dos editais
  // ===================================================================
  Future<int> inserirConcurso(Map<String, dynamic> concurso) async {
    final db = await database;
    return await db.insert('concursos', concurso);
  }

  Future<int> inserirMateria(Map<String, dynamic> materia) async {
    final db = await database;
    return await db.insert('materias', materia);
  }

  Future<int> inserirMissao(Map<String, dynamic> missao) async {
    final db = await database;
    return await db.insert('missoes', missao);
  }

  /// Libera a primeiríssima missão do concurso (a nº1 da matéria nº1).
  /// Deve ser chamado uma única vez, logo após popular o banco.
  Future<void> liberarPrimeiraMissao(int concursoId) async {
    final db = await database;
    final primeiraMateria = await db.query(
      'materias',
      where: 'concurso_id = ?',
      whereArgs: [concursoId],
      orderBy: 'ordem ASC',
      limit: 1,
    );
    if (primeiraMateria.isEmpty) return;

    final primeiraMissao = await db.query(
      'missoes',
      where: 'materia_id = ?',
      whereArgs: [primeiraMateria.first['id']],
      orderBy: 'ordem ASC',
      limit: 1,
    );
    if (primeiraMissao.isEmpty) return;

    await db.update('missoes', {'status': 'LIBERADA'},
        where: 'id = ?', whereArgs: [primeiraMissao.first['id']]);
  }
}
