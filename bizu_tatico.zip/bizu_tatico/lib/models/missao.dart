class Missao {
  final int id;
  final int materiaId;
  final String nome;
  final int ordem;
  final String prioridade; // ALTA | MEDIA | BAIXA
  final String status; // BLOQUEADA | LIBERADA | CONCLUIDA | REVISAO_OBRIGATORIA | CORTADA
  final String? materiaNome;

  Missao({
    required this.id,
    required this.materiaId,
    required this.nome,
    required this.ordem,
    required this.prioridade,
    required this.status,
    this.materiaNome,
  });

  factory Missao.fromMap(Map<String, dynamic> map) => Missao(
        id: map['id'] as int,
        materiaId: map['materia_id'] as int,
        nome: map['nome'] as String,
        ordem: map['ordem'] as int,
        prioridade: map['prioridade'] as String,
        status: map['status'] as String,
        materiaNome: map['materia_nome'] as String?,
      );

  bool get isRevisao => status == 'REVISAO_OBRIGATORIA';
}
