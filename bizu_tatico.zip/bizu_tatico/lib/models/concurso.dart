class Concurso {
  final int? id;
  final String nome; // 'ESPCEX' | 'ESA' | 'CFO_PMBA' | 'SOLDADO_PMBA'
  final double notaCorte;
  final int metaQuestoes;
  final String dataInicio;
  final String dataEstimadaConclusao;
  final String? dataProva;
  final bool editalPublicado;

  Concurso({
    this.id,
    required this.nome,
    required this.notaCorte,
    required this.metaQuestoes,
    required this.dataInicio,
    required this.dataEstimadaConclusao,
    this.dataProva,
    this.editalPublicado = false,
  });

  factory Concurso.fromMap(Map<String, dynamic> map) => Concurso(
        id: map['id'] as int?,
        nome: map['nome'] as String,
        notaCorte: (map['nota_corte'] as num).toDouble(),
        metaQuestoes: map['meta_questoes'] as int,
        dataInicio: map['data_inicio'] as String,
        dataEstimadaConclusao: map['data_estimada_conclusao'] as String,
        dataProva: map['data_prova'] as String?,
        editalPublicado: (map['edital_publicado'] as int) == 1,
      );

  Map<String, dynamic> toMap() => {
        if (id != null) 'id': id,
        'nome': nome,
        'nota_corte': notaCorte,
        'meta_questoes': metaQuestoes,
        'data_inicio': dataInicio,
        'data_estimada_conclusao': dataEstimadaConclusao,
        'data_prova': dataProva,
        'edital_publicado': editalPublicado ? 1 : 0,
      };

  String get nomeExibicao {
    switch (nome) {
      case 'ESPCEX':
        return 'EsPCEx';
      case 'ESA':
        return 'ESA';
      case 'CFO_PMBA':
        return 'CFO PMBA';
      case 'SOLDADO_PMBA':
        return 'Soldado PMBA';
      default:
        return nome;
    }
  }
}
