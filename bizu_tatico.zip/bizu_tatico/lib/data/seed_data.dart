import '../database/database_helper.dart';

/// =====================================================================
/// SEED DATA — mapeamento dos 4 editais em matérias + missões (tópicos)
/// =====================================================================
/// Cada matéria é uma lista ordenada de tópicos. A prioridade (usada no
/// Algoritmo de Corte de Pareto) é distribuída automaticamente:
/// primeiros ~40% = ALTA, próximos ~40% = MEDIA, últimos ~20% = BAIXA.
/// Ajuste manualmente os tópicos que você já sabe, pela sua experiência
/// de banca, que merecem ALTA prioridade específica.
/// =====================================================================

class ConcursoConfig {
  final String nome;
  final double notaCorte;
  final int metaQuestoes;
  final Map<String, List<String>> materias; // nome da matéria -> tópicos em ordem

  ConcursoConfig({
    required this.nome,
    required this.notaCorte,
    required this.metaQuestoes,
    required this.materias,
  });
}

// -----------------------------------------------------------------------
// SOLDADO PMBA — nota de corte 75% | meta 20 questões
// -----------------------------------------------------------------------
final _soldadoPmba = ConcursoConfig(
  nome: 'SOLDADO_PMBA',
  notaCorte: 0.75,
  metaQuestoes: 20,
  materias: {
    'Português': [
      'Interpretação de Texto',
      'Tipologia Textual',
      'Ortografia Oficial',
      'Coesão Textual',
      'Tempos e Modos Verbais',
      'Sintaxe (Coordenação/Subordinação)',
      'Concordância',
      'Regência',
      'Crase',
      'Colocação Pronominal',
    ],
    'Raciocínio Lógico-Matemático': [
      'Lógica de Argumentação',
      'Proposições',
      'Tabelas-verdade',
      'Equivalências e Negações',
      'Conjuntos',
      'Análise Combinatória',
      'Probabilidade',
    ],
    'Direito Constitucional': [
      'Princípios Fundamentais',
      'Artigo 5º (Direitos Individuais)',
      'Direitos Sociais e Nacionalidade',
      'Organização do Estado',
      'Administração Pública',
      'Artigo 144 (Segurança Pública)',
    ],
    'História do Brasil': [
      'Brasil Colônia',
      'Brasil Império',
      'Primeira República',
      'Era Vargas',
      'República Populista',
      'Ditadura Militar',
      'Nova República',
    ],
    'Geografia do Brasil': [
      'Território e Fronteiras',
      'Clima e Vegetação',
      'Relevo e Hidrografia',
      'População e Demografia',
      'Economia e Industrialização',
      'Urbanização',
      'Geografia da Bahia',
    ],
    'Informática': [
      'Conceitos Básicos de Hardware e Software',
      'Sistema Operacional Windows',
      'Editor de Texto (Word)',
      'Planilhas Eletrônicas (Excel)',
      'Internet e Navegadores',
      'Segurança da Informação',
      'Redes de Computadores',
    ],
    'Direito Administrativo': [
      'Princípios da Administração Pública',
      'Poderes Administrativos',
      'Atos Administrativos',
      'Agentes Públicos',
      'Licitações (Lei 14.133/21)',
      'Responsabilidade Civil do Estado',
    ],
    'Direito Penal': [
      'Teoria Geral do Crime',
      'Tipicidade e Ilicitude',
      'Culpabilidade',
      'Crimes contra a Pessoa',
      'Crimes contra o Patrimônio',
      'Crimes contra a Administração Pública',
    ],
    'Direitos Humanos': [
      'Evolução Histórica dos Direitos Humanos',
      'Declaração Universal de 1948',
      'Sistema Interamericano de Direitos Humanos',
      'Direitos Humanos e Atividade Policial',
      'Uso da Força e Proporcionalidade',
    ],
    'Igualdade Racial e de Gênero': [
      'Estatuto da Igualdade Racial',
      'Lei Maria da Penha',
      'Lei do Feminicídio',
      'Políticas de Ações Afirmativas',
      'Diversidade e Inclusão na Segurança Pública',
    ],
    'Direito Penal Militar': [
      'Crimes Militares — Conceito',
      'Crimes contra a Autoridade e Disciplina Militar',
      'Crimes contra o Serviço Militar',
      'Processo Penal Militar — Noções Gerais',
    ],
  },
);

// -----------------------------------------------------------------------
// CFO PMBA — nota de corte 80% | meta 30 questões
// -----------------------------------------------------------------------
final _cfoPmba = ConcursoConfig(
  nome: 'CFO_PMBA',
  notaCorte: 0.80,
  metaQuestoes: 30,
  materias: {
    'Direito Constitucional Avançado': [
      'Teoria da Constituição',
      'Controle de Constitucionalidade',
      'Direitos e Garantias Fundamentais (Aprofundado)',
      'Organização dos Poderes',
      'Segurança Pública — Art. 144 Aprofundado',
      'Intervenção Federal e Estadual',
    ],
    'Direito Administrativo': [
      'Regime Jurídico Administrativo',
      'Atos e Poderes Administrativos',
      'Nova Lei de Licitações 14.133/21 — Princípios',
      'Nova Lei de Licitações 14.133/21 — Modalidades e Fases',
      'Contratos Administrativos',
      'Responsabilidade Civil do Estado',
      'Improbidade Administrativa',
    ],
    'Direito Penal': [
      'Teoria Geral do Crime',
      'Concurso de Pessoas',
      'Penas e Medidas de Segurança',
      'Crimes contra a Pessoa',
      'Crimes contra o Patrimônio',
      'Crimes contra a Administração Pública',
      'Crimes Hediondos',
    ],
    'Direito Processual Penal': [
      'Inquérito Policial',
      'Ação Penal',
      'Prisões e Medidas Cautelares',
      'Provas',
      'Procedimentos',
    ],
    'Direito Penal Militar': [
      'Aplicação da Lei Penal Militar',
      'Crimes Militares em Espécie',
      'Crimes contra o Patrimônio sob Administração Militar',
      'Crimes contra a Autoridade e Disciplina Militar',
    ],
    'Direito Processual Penal Militar': [
      'Inquérito Policial Militar (IPM)',
      'Processo e Competência da Justiça Militar',
      'Prisão em Flagrante Militar',
    ],
    'Direitos Humanos': [
      'Tratados Internacionais de Direitos Humanos',
      'Uso Progressivo da Força',
      'Direitos Humanos Aplicados à Gestão de Crises',
    ],
    'Legislação Institucional da Bahia': [
      'Lei 7.990/01 — Organização Básica da PMBA',
      'Lei 13.201/14 — Estatuto dos Militares da Bahia',
      'Hierarquia e Disciplina Militar Estadual',
      'Regulamento Disciplinar da PMBA',
    ],
  },
);

// -----------------------------------------------------------------------
// EsPCEx — nota de corte 80% | meta 25 questões
// -----------------------------------------------------------------------
final _espcex = ConcursoConfig(
  nome: 'ESPCEX',
  notaCorte: 0.80,
  metaQuestoes: 25,
  materias: {
    'Matemática I — Álgebra e Funções': [
      'Conjuntos Numéricos',
      'Funções do 1º e 2º Grau',
      'Função Exponencial e Logarítmica',
      'Equações e Inequações',
      'Progressões (PA e PG)',
    ],
    'Matemática II — Geometria e Trigonometria': [
      'Geometria Plana',
      'Geometria Espacial',
      'Trigonometria no Triângulo Retângulo',
      'Trigonometria — Ciclo e Funções',
      'Geometria Analítica',
    ],
    'Matemática III — Combinatória e Matrizes': [
      'Análise Combinatória',
      'Probabilidade',
      'Matrizes e Determinantes',
      'Sistemas Lineares',
      'Polinômios',
    ],
    'Física': [
      'Cinemática',
      'Dinâmica (Leis de Newton)',
      'Estática e Hidrostática',
      'Termologia',
      'Óptica Geométrica',
      'Ondulatória',
      'Eletrostática',
      'Eletrodinâmica',
    ],
    'Química': [
      'Estrutura Atômica',
      'Tabela Periódica e Ligações Químicas',
      'Funções Inorgânicas',
      'Estequiometria',
      'Físico-Química — Termoquímica e Cinética',
      'Soluções',
      'Química Orgânica — Introdução',
      'Funções Orgânicas',
    ],
    'Português e Literatura': [
      'Interpretação de Texto',
      'Morfologia',
      'Sintaxe',
      'Concordância e Regência',
      'Escolas Literárias Brasileiras',
    ],
    'História': [
      'Idade Antiga e Média',
      'Idade Moderna',
      'Brasil Colônia',
      'Brasil Império',
      'República Brasileira',
      'História Contemporânea Mundial',
    ],
    'Geografia': [
      'Geografia Física Geral',
      'Geopolítica Mundial',
      'Território Brasileiro',
      'Economia Brasileira',
      'Globalização',
    ],
    'Inglês': [
      'Reading Comprehension',
      'Grammar — Tempos Verbais',
      'Vocabulário Militar e Técnico',
    ],
  },
);

// -----------------------------------------------------------------------
// ESA — nota de corte 75% | meta 20 questões
// -----------------------------------------------------------------------
final _esa = ConcursoConfig(
  nome: 'ESA',
  notaCorte: 0.75,
  metaQuestoes: 20,
  materias: {
    'Matemática': [
      'Conjuntos e Funções',
      'Equações e Inequações',
      'Geometria Plana',
      'Trigonometria Básica',
      'Análise Combinatória e Probabilidade',
    ],
    'Português Gramatical': [
      'Interpretação de Texto',
      'Ortografia',
      'Morfologia',
      'Sintaxe',
      'Concordância e Regência',
      'Crase',
    ],
    'História do Brasil': [
      'Brasil Colônia',
      'Brasil Império',
      'República Velha',
      'Era Vargas',
      'Ditadura Militar e Redemocratização',
    ],
    'Geografia do Brasil': [
      'Relevo e Clima',
      'População',
      'Economia',
      'Geopolítica Regional',
    ],
    'Inglês': [
      'Reading Comprehension',
      'Grammar Essentials',
    ],
    'Redação': [
      'Estrutura Dissertativa-Argumentativa',
      'Coesão e Coerência',
      'Temas Militares e Atualidades',
    ],
  },
);

final List<ConcursoConfig> todosOsConcursos = [
  _espcex,
  _esa,
  _cfoPmba,
  _soldadoPmba,
];

/// Distribui prioridade automaticamente: 40% ALTA, 40% MEDIA, 20% BAIXA.
String _prioridadePorIndice(int index, int total) {
  final alta = (total * 0.4).ceil();
  final media = (total * 0.4).ceil();
  if (index < alta) return 'ALTA';
  if (index < alta + media) return 'MEDIA';
  return 'BAIXA';
}

/// Popula o banco com os 4 concursos, suas matérias e missões.
/// Idempotente: se já houver concursos cadastrados, não faz nada.
Future<void> seedDatabaseIfNeeded() async {
  final dbHelper = DatabaseHelper.instance;
  final db = await dbHelper.database;

  final existentes = await db.query('concursos', limit: 1);
  if (existentes.isNotEmpty) return; // já foi semeado antes

  final agora = DateTime.now();

  for (final config in todosOsConcursos) {
    // Estimativa inicial ingênua: 1 dia por missão (o app recalcula
    // automaticamente conforme o desempenho real do aluno).
    final totalMissoes =
        config.materias.values.fold<int>(0, (soma, lista) => soma + lista.length);
    final dataEstimada = agora.add(Duration(days: totalMissoes));

    final concursoId = await dbHelper.inserirConcurso({
      'nome': config.nome,
      'nota_corte': config.notaCorte,
      'meta_questoes': config.metaQuestoes,
      'data_inicio': agora.toIso8601String(),
      'data_estimada_conclusao': dataEstimada.toIso8601String(),
      'data_prova': null,
      'edital_publicado': 0,
    });

    int ordemMateria = 1;
    for (final entry in config.materias.entries) {
      final materiaId = await dbHelper.inserirMateria({
        'concurso_id': concursoId,
        'nome': entry.key,
        'ordem': ordemMateria,
      });
      ordemMateria++;

      final topicos = entry.value;
      for (int i = 0; i < topicos.length; i++) {
        await dbHelper.inserirMissao({
          'materia_id': materiaId,
          'nome': topicos[i],
          'ordem': i + 1,
          'prioridade': _prioridadePorIndice(i, topicos.length),
          'status': 'BLOQUEADA',
        });
      }
    }

    // Libera a primeiríssima missão do concurso (matéria 1, tópico 1)
    await dbHelper.liberarPrimeiraMissao(concursoId);
  }
}
