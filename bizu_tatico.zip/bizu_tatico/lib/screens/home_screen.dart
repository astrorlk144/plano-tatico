import 'package:flutter/material.dart';
import '../database/database_helper.dart';
import '../data/seed_data.dart';
import '../models/concurso.dart';
import 'concurso_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  bool _carregando = true;
  List<Concurso> _concursos = [];

  @override
  void initState() {
    super.initState();
    _inicializar();
  }

  Future<void> _inicializar() async {
    await seedDatabaseIfNeeded();
    final db = await DatabaseHelper.instance.database;
    final rows = await db.query('concursos', orderBy: 'nome ASC');
    setState(() {
      _concursos = rows.map((r) => Concurso.fromMap(r)).toList();
      _carregando = false;
    });
  }

  IconData _iconePara(String nome) {
    switch (nome) {
      case 'ESPCEX':
        return Icons.school;
      case 'ESA':
        return Icons.military_tech;
      case 'CFO_PMBA':
        return Icons.local_police;
      case 'SOLDADO_PMBA':
        return Icons.shield;
      default:
        return Icons.flag;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Bizú Tático'),
        centerTitle: true,
      ),
      body: _carregando
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                const Padding(
                  padding: EdgeInsets.only(bottom: 16),
                  child: Text(
                    'Escolha seu concurso. A partir daqui o app assume o comando.',
                    style: TextStyle(fontSize: 14, color: Colors.black54),
                  ),
                ),
                ..._concursos.map((c) => _cardConcurso(c)),
              ],
            ),
    );
  }

  Widget _cardConcurso(Concurso concurso) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: 2,
      child: ListTile(
        contentPadding: const EdgeInsets.all(16),
        leading: CircleAvatar(
          radius: 26,
          backgroundColor: Colors.blueGrey.shade800,
          child: Icon(_iconePara(concurso.nome), color: Colors.white),
        ),
        title: Text(
          concurso.nomeExibicao,
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
        ),
        subtitle: Text(
          'Nota de corte: ${(concurso.notaCorte * 100).toStringAsFixed(0)}%  •  '
          'Meta diária: ${concurso.metaQuestoes} questões',
        ),
        trailing: const Icon(Icons.chevron_right),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => ConcursoScreen(concursoId: concurso.id!)),
          );
        },
      ),
    );
  }
}
