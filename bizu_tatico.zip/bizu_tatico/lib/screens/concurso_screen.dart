import 'package:flutter/material.dart';
import '../database/database_helper.dart';
import '../models/concurso.dart';
import '../models/missao.dart';
import '../widgets/dashboard_chart.dart';

class ConcursoScreen extends StatefulWidget {
  final int concursoId;
  const ConcursoScreen({super.key, required this.concursoId});

  @override
  State<ConcursoScreen> createState() => _ConcursoScreenState();
}

class _ConcursoScreenState extends State<ConcursoScreen> {
  final _dbHelper = DatabaseHelper.instance;

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Bizú Tático'),
          bottom: const TabBar(
            tabs: [
              Tab(icon: Icon(Icons.flag), text: 'Missão do Dia'),
              Tab(icon: Icon(Icons.pie_chart), text: 'Painel'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            _MissaoDoDiaTab(concursoId: widget.concursoId, dbHelper: _dbHelper),
            _PainelTab(concursoId: widget.concursoId, dbHelper: _dbHelper),
          ],
        ),
      ),
    );
  }
}

// =========================================================================
// ABA 1 — COMANDO DIÁRIO
// =========================================================================
class _MissaoDoDiaTab extends StatefulWidget {
  final int concursoId;
  final DatabaseHelper dbHelper;
  const _MissaoDoDiaTab({required this.concursoId, required this.dbHelper});

  @override
  State<_MissaoDoDiaTab> createState() => _MissaoDoDiaTabState();
}

class _MissaoDoDiaTabState extends State<_MissaoDoDiaTab> {
  Missao? _missao;
  Concurso? _concurso;
  bool _carregando = true;
  final _acertosController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _carregar();
  }

  @override
  void dispose() {
    _acertosController.dispose();
    super.dispose();
  }

  Future<void> _carregar() async {
    setState(() => _carregando = true);
    final db = await widget.dbHelper.database;
    final concursoRows = await db.query('concursos', where: 'id = ?', whereArgs: [widget.concursoId]);
    final concurso = Concurso.fromMap(concursoRows.first);

    final missaoMap = await widget.dbHelper.getMissaoDoDia(widget.concursoId);

    setState(() {
      _concurso = concurso;
      _missao = missaoMap != null ? Missao.fromMap(missaoMap) : null;
      _acertosController.clear();
      _carregando = false;
    });
  }

  Future<void> _registrar() async {
    if (_missao == null || _concurso == null) return;
    final acertos = int.tryParse(_acertosController.text);
    final meta = _concurso!.metaQuestoes;

    if (acertos == null || acertos < 0 || acertos > meta) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Informe um valor entre 0 e $meta.')),
      );
      return;
    }

    final aprovado = await widget.dbHelper.registrarTentativa(
      missaoId: _missao!.id,
      questoesTotal: meta,
      acertos: acertos,
    );

    if (!mounted) return;

    await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(aprovado ? '✅ Missão Cumprida!' : '🔴 Abaixo da Nota de Corte'),
        content: Text(
          aprovado
              ? 'Você bateu a meta e a próxima missão foi liberada.'
              : _concurso!.editalPublicado
                  ? 'O edital já foi publicado, então a data da prova não muda. '
                    'Um tópico de baixa prioridade lá na frente foi cortado para '
                    'você focar no que mais cai. Essa missão volta amanhã como revisão obrigatória.'
                  : 'Como o edital ainda não saiu, essa missão volta amanhã como '
                    'revisão obrigatória e sua data estimada de conclusão foi empurrada em +1 dia.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Entendido')),
        ],
      ),
    );

    _carregar();
  }

  Color _corPrioridade(String prioridade) {
    switch (prioridade) {
      case 'ALTA':
        return Colors.red.shade600;
      case 'MEDIA':
        return Colors.amber.shade700;
      default:
        return Colors.green.shade600;
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_carregando) return const Center(child: CircularProgressIndicator());

    if (_missao == null) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Text(
            '🎯 Parabéns! Todas as missões deste edital foram concluídas.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
        ),
      );
    }

    final missao = _missao!;
    final concurso = _concurso!;

    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          if (missao.isRevisao)
            Container(
              padding: const EdgeInsets.all(10),
              margin: const EdgeInsets.only(bottom: 12),
              decoration: BoxDecoration(
                color: Colors.red.shade50,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.red.shade200),
              ),
              child: Row(
                children: const [
                  Icon(Icons.replay, color: Colors.red),
                  SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'REVISÃO OBRIGATÓRIA — você não bateu a meta ontem.',
                      style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
              ),
            ),
          Card(
            elevation: 3,
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'ORDEM DO DIA',
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                      color: Colors.blueGrey.shade400,
                      letterSpacing: 1.2,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(missao.materiaNome ?? '',
                      style: const TextStyle(fontSize: 14, color: Colors.black54)),
                  const SizedBox(height: 4),
                  Text(missao.nome,
                      style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 12),
                  Chip(
                    label: Text('Prioridade ${missao.prioridade}',
                        style: const TextStyle(color: Colors.white, fontSize: 12)),
                    backgroundColor: _corPrioridade(missao.prioridade),
                  ),
                  const SizedBox(height: 20),
                  Text('Meta: ${concurso.metaQuestoes} questões  •  '
                      'Nota de corte: ${(concurso.notaCorte * 100).toStringAsFixed(0)}%'),
                ],
              ),
            ),
          ),
          const SizedBox(height: 24),
          Text('Quantas você acertou de ${concurso.metaQuestoes}?',
              style: const TextStyle(fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          TextField(
            controller: _acertosController,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(
              border: OutlineInputBorder(),
              hintText: 'Ex: 17',
            ),
          ),
          const SizedBox(height: 16),
          ElevatedButton(
            onPressed: _registrar,
            style: ElevatedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 14)),
            child: const Text('Registrar Tentativa'),
          ),
        ],
      ),
    );
  }
}

// =========================================================================
// ABA 2 — PAINEL / DASHBOARD
// =========================================================================
class _PainelTab extends StatefulWidget {
  final int concursoId;
  final DatabaseHelper dbHelper;
  const _PainelTab({required this.concursoId, required this.dbHelper});

  @override
  State<_PainelTab> createState() => _PainelTabState();
}

class _PainelTabState extends State<_PainelTab> {
  Map<String, dynamic>? _dados;
  bool _carregando = true;

  @override
  void initState() {
    super.initState();
    _carregar();
  }

  Future<void> _carregar() async {
    setState(() => _carregando = true);
    final dados = await widget.dbHelper.getDashboardData(widget.concursoId);
    setState(() {
      _dados = dados;
      _carregando = false;
    });
  }

  Future<void> _publicarEdital() async {
    final dataEscolhida = await showDatePicker(
      context: context,
      initialDate: DateTime.now().add(const Duration(days: 90)),
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 730)),
      helpText: 'Data oficial da prova',
    );
    if (dataEscolhida == null) return;

    await widget.dbHelper.publicarEdital(widget.concursoId, dataEscolhida);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Edital publicado! A data da prova agora é fixa — '
            'o app passa a cortar tópicos de baixa prioridade em caso de falha.'),
      ),
    );
    _carregar();
  }

  String _formatarData(String? isoDate) {
    if (isoDate == null) return '—';
    final d = DateTime.parse(isoDate);
    return '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}';
  }

  @override
  Widget build(BuildContext context) {
    if (_carregando) return const Center(child: CircularProgressIndicator());
    final dados = _dados!;
    final progresso = (dados['progresso_percentual'] as double).clamp(0.0, 1.0);
    final editalPublicado = dados['edital_publicado'] as bool;

    return RefreshIndicator(
      onRefresh: _carregar,
      child: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Card(
            elevation: 2,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: DashboardChart(
                concluidas: dados['concluidas'] as int,
                restantes: dados['restantes'] as int,
                cortadas: dados['cortadas'] as int,
              ),
            ),
          ),
          const SizedBox(height: 20),
          Text('Progresso geral: ${(progresso * 100).toStringAsFixed(0)}%',
              style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: LinearProgressIndicator(
              value: progresso,
              minHeight: 12,
              backgroundColor: Colors.grey.shade300,
              valueColor: AlwaysStoppedAnimation(Colors.green.shade600),
            ),
          ),
          const SizedBox(height: 24),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(editalPublicado ? Icons.lock : Icons.lock_open,
                          color: editalPublicado ? Colors.red : Colors.blueGrey),
                      const SizedBox(width: 8),
                      Text(
                        editalPublicado ? 'Fase Pós-Edital (data travada)' : 'Fase Pré-Edital',
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Text('Data estimada de conclusão: ${_formatarData(dados['data_estimada_conclusao'] as String?)}'),
                  if (editalPublicado) ...[
                    const SizedBox(height: 4),
                    Text('Data da prova: ${_formatarData(dados['data_prova'] as String?)}'),
                  ],
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          if (!editalPublicado)
            OutlinedButton.icon(
              onPressed: _publicarEdital,
              icon: const Icon(Icons.campaign),
              label: const Text('Publicar Edital (travar data da prova)'),
            ),
        ],
      ),
    );
  }
}
